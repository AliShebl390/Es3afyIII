<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class soscontacts extends Model
{
    protected $table = 'soscontacts';
}
