<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class get extends Model
{
    protected $table = 'gets';
}
